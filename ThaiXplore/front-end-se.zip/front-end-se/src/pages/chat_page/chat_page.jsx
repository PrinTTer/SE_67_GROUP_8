const ChatPage = () => {
    return (
        <div className="text-9xl">
            ChatPage
        </div>
    );
}


export default ChatPage;